#!/usr/bin/env node
require('babel-polyfill');
require('./dist/index');